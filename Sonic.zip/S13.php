<!doctype html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <title>Musica De Sonic</title>
    <link rel="stylesheet" href="../ModelosEstilos/CSS2.css">
</head>

<body>
    <?php require_once "../ModelosEstilos/SonicM05.php"; $m = new SonicM05(); $v = array();
if (isset($_POST["nz"])) { $v = $m->getNZ(); } if (isset($_POST["zonacancion"])) { $v = $m->getZonaCancion(); }
if (isset($_POST["aparicion"])) { $v = $m->getCancionJuego(); } if (isset($_POST["temap"])) { $v = $m->getTemaP(); }
if (isset($_POST["temafinal"])) { $v = $m->getTemaFinal(); } if (isset($_POST["artista"])) { $v = $m->getArtista(); }
echo "<br><form action='S13.php' method='post'><select name='nzv'>";
foreach ($m->sacaNZ() as $nz) { echo "<option value='$nz'>" . $nz . "</option>"; }
echo "</select><input type='submit' value='Buscar Nº Zona' name='nz'><select name='zcv'>";
foreach ($m->sacaZonaCancion() as $zonacancion) { echo "<option value='$zonacancion'>" . $zonacancion . "</option>"; }
echo "</select><input type='submit' value='Buscar Zona' name='zonacancion'><select name='cjv'>";
foreach ($m->sacaCancionJuego() as $cancionjuego) { echo "<option value='$cancionjuego'>" . $cancionjuego . "</option>"; }
echo "</select><input type='submit' value='Buscar Aparicion' name='aparicion'><br><br><select name='temapv'>";
foreach ($m->sacaTemaP() as $temap) { echo "<option value='$temap'>" . $temap . "</option>"; }
echo "</select><input type='submit' value='Buscar Tema Principal' name='temap'><select name='temafinalv'>";
foreach ($m->sacaTemaFinal() as $temafinal) { echo "<option value='$temafinal'>" . $temafinal . "</option>"; }
echo "</select><input type='submit' value='Buscar Tema Final' name='temafinal'><select name='artistav'>";
foreach ($m->sacaArtista() as $artista) { echo "<option value='$artista'>" . $artista . "</option>"; }
echo "</select><input type='submit' value='Buscar Artista Tema Principal y Final' name='artista'></form><br>";
if (isset($_POST["nz"]) || isset($_POST["zonacancion"]) || isset($_POST["aparicion"]) || isset($_POST["temap"])
    || isset($_POST["artista"]) || isset($_POST["temafinal"])) {
    echo "<table style='text-align: center'><tr><th>Zona</th><th>Juego</th><th>Tema Principal</th><th>Tema Final</th></tr>";
    foreach ($v as $c) {
        echo "<tr><td id='ng'>" . $c["zonacancion"] . "<br><br>Nº Zona: " . $c["nz"] .
            "<br><br><img src='imgzonas/" . $c["zonacancion"] . " Act 1.png' width='350px' height='350px'></td><td>" .
            $c["cancionjuego"]. "<br><br><img src='imgseriepelilogo/" . $c["cancionjuego"] .
            ".png' width='350px' height='350px'></td><td>";
        if ($c["temap"] != "No") {
            echo $c["temap"] . "<br><br>" . $c["artistatp"] . "<br><br><audio src='musica/" . $c["temap"] .
                ".oga' style='width: 250px;' controls=''></audio></div>";
        } else { echo "<img src='imgseriepelilogo/" . $c["cancionjuego"] . ".png' width='350px' height='350px'>"; }
        echo "</td><td>";
        if ($c["temafinal"] != "No") {
            echo $c["temafinal"] . "<br><br>" . $c["artistatf"] . "<br><br><audio src='musica/" . $c["temafinal"] .
                ".oga' style='width: 250px;' controls=''></audio></div>";
        } else { echo "<img src='imgseriepelilogo/" . $c["cancionjuego"] . ".png' width='350px' height='350px'>"; }
        echo "</td></tr>";
    }
    echo "</table>";
}
?>
</body>

</html>