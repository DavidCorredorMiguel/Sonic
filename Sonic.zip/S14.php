<!doctype html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <title>Buscar Musica Sonic</title>
    <link rel="stylesheet" href="../ModelosEstilos/CSS2.css">
</head>

<body>
    <form action='S14.php' method='post' style="margin-top: 10px; text-align: center;">
        <input type="text" name="nz" placeholder="Nº Zona"> <input type="text" name="zona" placeholder="Zona">
        <input type="text" name="aparicion" placeholder="Juego">
        <input type="text" name="temap" placeholder="Tema Principal">
        <input type="text" name="temafinal" placeholder="Tema Final">
        <input type="text" name="artista" placeholder="Artista (Principal y Final)">
        <br><br><input type="submit" name="buscarmusica" value="Buscar Musica">
    </form> <?php try { if (isset($_POST["buscarmusica"])) { $con = new PDO("mysql:host=localhost; dbname=sonicdb", "root", "");
        $con->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION); $con->exec("set character set utf8");
        $res = $con->prepare("SELECT * FROM musica WHERE nz=? OR zonacancion=? OR cancionjuego=? OR temap=? OR temafinal=?
            OR artistatp=? OR artistatf=?"); $artista = $_POST["artista"]; $res->bindParam(1, $_POST["nz"]);
        $res->bindParam(2, $_POST["zonacancion"]); $res->bindParam(3, $_POST["cancionjuego"]); $res->bindParam(4, $_POST["temap"]);
        $res->bindParam(5, $_POST["temafinal"]); $res->bindParam(6, $artista); $res->bindParam(7, $artista); $res->execute();
        echo "<table style='text-align: center'><tr><th>Zona</th><th>Juego</th><th>Tema Principal</th><th>Tema Final</th></tr>";
        while ($c = $res->fetch(PDO::FETCH_ASSOC)) {
            echo "<tr><td id='ng'>" . $c["zonacancion"] . "<br><br>Nº Zona: " . $c["nz"] .
                "<br><br><img src='imgzonas/" . $c["zonacancion"] . " Act 1.png' width='350px' height='350px'></td><td>" .
                $c["cancionjuego"]. "<br><br><img src='imgseriepelilogo/" . $c["cancionjuego"] .
                ".png' width='350px' height='350px'></td><td>";
            if ($c["temap"] != "No") {
                echo $c["temap"] . "<br><br>" . $c["artistatp"] . "<br><br><audio src='musica/" . $c["temap"] .
                    ".oga' style='width: 250px;' controls=''></audio></div>";
            } else { echo "<img src='imgseriepelilogo/" . $c["cancionjuego"] . ".png' width='350px' height='350px'>"; }
            echo "</td><td>";
            if ($c["temafinal"] != "No") {
                echo $c["temafinal"] . "<br><br>" . $c["artistatf"] . "<br><br><audio src='musica/" . $c["temafinal"] .
                    ".oga' style='width: 250px;' controls=''></audio></div>";
            } else { echo "<img src='imgseriepelilogo/" . $c["cancionjuego"] . ".png' width='350px' height='350px'>"; }echo "</td></tr>";
        } echo "</table>"; $res->closeCursor();
    }
} catch (Exception $e) { echo "¡Error! " . $e->getMessage(); } finally { $con = null; } ?>
</body>

</html>