<!doctype html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <title>Jefes De Sonic</title>
    <link rel='stylesheet' href='https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css'>
    <link rel="stylesheet" href="../ModelosEstilos/CSS2.css">
    <script src='https://code.jquery.com/jquery-3.2.1.slim.min.js'></script>
    <script src='https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js'></script>
</head>

<body> <?php require_once "../ModelosEstilos/SonicM04.php"; $m = new SonicM04(); $v = array();
if (isset($_POST["nz"])) { $v = $m->getNZ(); } if (isset($_POST["zona"])) { $v = $m->getZona(); }
if (isset($_POST["aparicion"])) { $v = $m->getAparicion(); } if (isset($_POST["jefe"])) { $v = $m->getJefe(); }
echo "<br><form action='S10.php' method='post'><select name='nzv'>";
foreach ($m->sacaNZ() as $nz) { echo "<option value='$nz'>" . $nz . "</option>"; }
echo "</select><input type='submit' value='Buscar Nº Zona' name='nz'><select name='zonav'>";
foreach ($m->sacaZona() as $zona) { echo "<option value='$zona'>" . $zona . "</option>"; }
echo "</select><input type='submit' value='Buscar Zona' name='zona'><select name='aparicionv'>";
foreach ($m->sacaAparicion() as $aparicion) { echo "<option value='$aparicion'>" . $aparicion . "</option>"; }
echo "</select><input type='submit' value='Buscar Aparicion' name='aparicion'><br><br><select name='jefev'>";
foreach ($m->sacaJefe() as $jefe) { echo "<option value='$jefe'>" . $jefe . "</option>"; }
echo "</select><input type='submit' value='Buscar Jefe' name='jefe'></form><br>";
if (isset($_POST["nz"]) || isset($_POST["zona"]) || isset($_POST["aparicion"]) || isset($_POST["jefe"])) {
    echo "<table style='text-align: center'><tr><th>Zona</th><th>Aparicion</th><th>Jefe/s</th></tr>";
    foreach ($v as $c) {
        echo "<tr><td id='ng'>" . $c["zona"] . "<br><br>Nº Zona: " . $c["nz"] .
            "<br><br><img src='imgzonas/" . $c["zona"] . " Act 1.png' width='475px' height='475px'></td><td>" .
            $c["aparicion1"]. "<br><br><img src='imgseriepelilogo/" . $c["aparicion1"] . ".png' width='475px' height='475px'>
            </td><td id='ng'><div id='cc' class='carousel slide' data-ride='carousel'>
            <div id='cc' class='carousel slide' data-ride='carousel'><br><div class='carousel-inner'>
            <div class='carousel-item active'>";
        if ($c["jefe1"] != "No"){
            echo $c["jefe1"] . "<br><br><img src='imgrobotsyjefes/" . $c["jefe1"] . ".png' width='475px' height='475px'></div>";
        } else { echo "<img src='imgseriepelilogo/" . $c["aparicion1"] . ".png' width='475px' height='475px'>"; }
        for ($p = 2; $p < 9; $p++) {
            if ($c["jefe$p"] != "No") {
                echo "<div class='carousel-item'>" . $c["jefe$p"] . "<br><br><img src='imgrobotsyjefes/" . $c["jefe$p"] .
                ".png' width='475px' height='475px'></div>";
            } else{ echo ""; }
        }
        echo "</div><a class='carousel-control-prev' href='#cc' data-slide='prev'></a>
            <a class='carousel-control-next' href='#cc' data-slide='next'></a></div></td></tr>";
    } echo "</table>";
} ?> </body>

</html>
