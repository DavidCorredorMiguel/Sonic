<!doctype html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <title>Musica Zonas De Sonic</title>
    <link rel='stylesheet' href='https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css'>
    <link rel="stylesheet" href="../ModelosEstilos/CSS2.css">
    <script src='https://code.jquery.com/jquery-3.2.1.slim.min.js'></script>
    <script src='https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js'></script>
</head>

<body> <?php require_once "../ModelosEstilos/SonicM06.php"; $m = new SonicM06(); $v = array();
if (isset($_POST["nz"])) { $v = $m->getNZ(); } if (isset($_POST["zona"])) { $v = $m->getZonaCancion(); }
if (isset($_POST["aparicion"])) { $v = $m->getCancionJuego(); } if (isset($_POST["cact"])) { $v = $m->getCAct(); }
if(isset($_POST["artista"])) { $v = $m->getArtista(); }echo "<br><form action='S16.php' method='post'><select name='nzv'>";
foreach ($m->sacaNZ() as $nz) { echo "<option value='$nz'>" . $nz . "</option>"; }
echo "</select><input type='submit' value='Buscar Nº Zona' name='nz'><select name='zcv'>";
foreach ($m->sacaZonaCancion() as $zona) { echo "<option value='$zona'>" . $zona . "</option>"; }
echo "</select><input type='submit' value='Buscar Zona' name='zona'><select name='cjv'>";
foreach ($m->sacaCancionJuego() as $aparicion) { echo "<option value='$aparicion'>" . $aparicion . "</option>"; }
echo "</select><input type='submit' value='Buscar Aparicion' name='aparicion'><br><br><select name='cactv'>";
foreach ($m->sacaCAct() as $cact) { echo "<option value='$cact'>" . $cact . "</option>"; }
echo "</select><input type='submit' value='Buscar Musica Zona' name='cact'><br><br><select name='artistav'>";
foreach ($m->sacaArtista() as $artista) { echo "<option value='$artista'>" . $artista . "</option>"; }
echo "</select><input type='submit' value='Buscar Artista Zona' name='artista'></form><br>";
if (isset($_POST["nz"]) || isset($_POST["zona"]) || isset($_POST["aparicion"]) || isset($_POST["cact"]) || isset($_POST["artista"])) {
    echo "<table style='text-align: center'><tr><th>Zona</th><th>Juego</th><th>Musica y Artista/s</th></tr>";
    foreach ($v as $c) {
        echo "<tr><td id='ng'>" . $c["zonacancion"] . "<br><br>Nº Zona: " . $c["nz"] .
            "<img src='imgzonas/" . $c["zonacancion"] . " Act 1.png' width='350px' height='350px'></td><td>" .
            $c["cancionjuego"] . "<br><br><img src='imgseriepelilogo/" . $c["cancionjuego"] .
            ".png' width='300px' height='300px'></td><td id='ng'><div id='cc' class='carousel slide' data-ride='carousel'>
            <div class='carousel-inner'><div class='carousel-item active'>";
        if ($c["cact1"] != "No") { echo "Artista/s: " . $c["artistac1"] . "<br>";
            if ($c["cact1"] != "Act 1"){ echo "Cancion: " . $c["cact1"] . "<br><audio src='musica/" . $c["cact1"]; }
            else { echo "Cancion: " . $c["zonacancion"] . " Act 1<br><audio src='musica/" . $c["zonacancion"] . " Act 1"; }
            echo ".oga' style='width: 250px;' controls=''></audio>";
        } else { echo ""; } echo "<br><img src='imgzonas/" . $c["zonacancion"] . " Act 1.png' width='300px' height='300px'></div>";
        for ($p = 2; $p < 8; $p++) { echo "<div class='carousel-item'>";
            if ($c["cact$p"] != "No") { echo "Artista/s: " . $c["artistac$p"] . "<br>";
                if ($c["cact".$p] != "Act ".$p){ echo "Cancion: " . $c["cact".$p] . "<br><audio src='musica/" . $c["cact".$p]; }
                else {echo "Cancion: " . $c["zonacancion"] . " Act ".$p."<br><audio src='musica/" . $c["zonacancion"]." Act ".$p; }
                echo ".oga' style='width: 250px;' controls=''></audio><br><img src='imgzonas/" . $c["zonacancion"] .
                    " Act $p.png' width='300px' height='300px'>";
            } else { echo "<img src='imgseriepelilogo/" . $c["cancionjuego"] . ".png' width='300px' height='300px'>"; } echo "</div>";
        }
        echo "<a class='carousel-control-prev' href='#cc' data-slide='prev'></a>
            <a class='carousel-control-next' href='#cc' data-slide='next'></a></div></td></tr>";
    } echo "</table>";
} ?> </body>

</html>
