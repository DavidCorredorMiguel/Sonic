<!doctype html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <title>Buscar Musica Zonas Sonic</title>
    <link rel='stylesheet' href='https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css'>
    <link rel="stylesheet" href="../ModelosEstilos/CSS2.css">
    <script src='https://code.jquery.com/jquery-3.2.1.slim.min.js'></script>
    <script src='https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js'></script>
</head>

<body>
    <form action='S20.php' method='post' style="margin-top: 10px; text-align: center;">
        <input type="text" name="nz" placeholder="Nº Zona"> <input type="text" name="zona" placeholder="Zona">
        <input type="text" name="aparicion" placeholder="Juego">
        <input type="text" name="cjefe" placeholder="Tema Jefe">
        <input type="text" name="artista" placeholder="Artista Jefe"><br><br>
        <input type="submit" name="buscarmusicazona" value="Buscar Musica Zona">
    </form> <?php try { if (isset($_POST["buscarmusicazona"])) { $con = new PDO("mysql:host=localhost; dbname=sonicdb", "root", "");
        $con->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION); $con->exec("set character set utf8");
        $res = $con->prepare("SELECT * FROM musicajefes WHERE nz=? OR zonacancion=? OR cancionjuego=? OR cjefe1=? OR cjefe2=?
            OR cjefe3=? OR cjefe4=? OR cjefe5=? OR cjefe6=? OR cjefe7=? OR artistaj1=? OR artistaj2=? OR artistaj3=? OR artistaj4=?
            OR artistaj5=? OR artistaj6=? OR artistaj7=".$_POST['artista']); $cjefe = $_POST["cjefe"]; $artista = $_POST["artista"];
        $res->bindParam(1, $_POST["nz"]); $res->bindParam(2, $_POST["zona"]); $res->bindParam(3, $_POST["cancionjuego"]);
        $res->bindParam(4, $cjefe); $res->bindParam(5, $cjefe); $res->bindParam(6, $cjefe); $res->bindParam(7, $cjefe);
        $res->bindParam(8, $cjefe); $res->bindParam(9, $cjefe); $res->bindParam(10, $cjefe); $res->bindParam(11, $artista);
        $res->bindParam(12, $artista); $res->bindParam(13, $artista); $res->bindParam(14, $artista); $res->bindParam(15, $artista);
        $res->bindParam(16, $artista); $res->bindParam(17, $artista); $res->execute();
        echo "<table style='text-align: center'><tr><th>Zona</th><th>Juego</th><th>Musica y Artista/s</th></tr>";
        while ($c = $res->fetch(PDO::FETCH_ASSOC)) {
            echo "<tr><td bgcolor='black'><p style='color: white'>" . $c["zonacancion"] . "<br><br>Nº Zona: " . $c["nz"] .
                "</p><img src='imgzonas/" . $c["zonacancion"] . " Act 1.png' width='350px' height='350px'></td><td>" .
                $c["cancionjuego"] . "<br><br><img src='imgseriepelilogo/" . $c["cancionjuego"] .
                ".png' width='300px' height='300px'></td><td bgcolor='black' style='color: white'>
                <div id='cc' class='carousel slide' data-ride='carousel'>
                <div class='carousel-inner'><div class='carousel-item active'>";
            if ($c["cjefe1"] != "No") {
                echo "Artista/s: " . $c["artistaj1"] . "<br>Jefe: " . $c["jefe1"] . "<br>Cancion: " . $c["cjefe1"] .
                    "<br><audio src='musica/Jefe " . $c["cjefe1"] . ".oga' style='width: 250px;' controls=''></audio>
                    <br><img src='imgrobotsyjefes/" . $c["jefe1"] . ".png' width='300px' height='300px'>";
            } else { echo "<img src='imgseriepelilogo/".$c["cancionjuego"].".png' width='300px' height='300px'>"; } echo "</div>";
            for ($p = 2; $p <= 8; $p++) { echo "<div class='carousel-item'>";
                if ($c["cjefe$p"] != "No") {
                    echo "Artista/s: " . $c["artistaj$p"] . "<br>Jefe: " . $c["jefe$p"] . "<br>Cancion: " .
                        $c["cjefe$p"] . "<br><audio src='musica/Jefe " . $c["cjefe$p"] .
                        ".oga' style='width: 250px;' controls=''></audio><br><img src='imgrobotsyjefes/" .
                        $c["jefe$p"] . ".png' width='300px' height='300px'>";
                } else {echo "<img src='imgseriepelilogo/".$c["cancionjuego"].".png' width='300px' height='300px'>";}echo"</div>";
            }
            echo "<a class='carousel-control-prev' href='#cc' data-slide='prev'></a>
                <a class='carousel-control-next' href='#cc' data-slide='next'></a></div></td></tr>";
        } echo "</table>"; $res->closeCursor();
    }
} catch (Exception $e) { echo "¡Error! " . $e->getMessage(); } finally { $con = null; } ?> </body>

</html>
