<!doctype html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <title>Videojuegos De Sonic</title>
    <link rel='stylesheet' href='https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css'>
    <link rel="stylesheet" href="../ModelosEstilos/CSS2.css">
    <script src='https://code.jquery.com/jquery-3.2.1.slim.min.js'></script>
    <script src='https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js'></script>
</head>

<body> <?php require_once "../ModelosEstilos/SonicM01.php"; $m = new SonicM01(); $v = array();
if (isset($_POST["juego"])) { $v = $m->getJuego(); } if (isset($_POST["plat"])) { $v = $m->getPlataforma(); }
if (isset($_POST["genero"])) { $v = $m->getGenero(); } if (isset($_POST["tipoNPC"])) { $v = $m->getTipoNPC(); }
echo "<br><form action='S01.php' method='post'><select name='juegov'>";
foreach ($m->sacaJuego() as $juego) { echo "<option value='$juego'>" . $juego . "</option>"; }
echo "</select><input type='submit' value='Buscar Juego' name='juego'><select name='platv'>";
foreach ($m->sacaPlataforma() as $plat) { echo "<option value='$plat'>" . $plat . "</option>"; }
echo "</select><input type='submit' value='Buscar Plataforma' name='plat'><select name='generov'>";
foreach ($m->sacaGenero() as $genero) { echo "<option value='$genero'>" . $genero . "</option>"; }
echo "</select><input type='submit' value='Buscar Genero' name='genero'><br><br><select name='tipoNPCv'>";
foreach ($m->sacaTipoNPC() as $tipoNPC) { echo "<option value='$tipoNPC'>NPC (Personaje No Jugador): " . $tipoNPC . "</option>"; }
echo "</select><input type='submit' value='Buscar Tipo De NPC' name='tipoNPC'></form><br>";
if (isset($_POST["juego"]) || isset($_POST["plat"]) || isset($_POST["genero"])
    || isset($_POST["tipoNPC"])) {
    echo "<table style='text-align: center'><tr><th>Videojuego y Plataforma/s</th><th>Género, Desarrollador y Editor</th>
    <th colspan='2'>Personaje Jugable y/o No Jugable (NPC)</th></tr>";
    foreach ($v as $c) {
        echo "<tr><td><div id='cc' class='carousel slide' data-ride='carousel'>" .
            $c["nombrejuego"] . "<br><div class='carousel-inner'><div class='carousel-item active'>"
            . $c["plat1"] . "<br><br><img src='imgjuegos/" . $c["nombrejuego"] . " " .
            $c["plat1"] . ".png' width='350px' height='350px'></div>";
        for ($p = 2; $p < 17; $p++) {
            if ($c["plat$p"] != "No") {
                echo "<div class='carousel-item'>" . $c["plat$p"] . "<br><br><img src='imgjuegos/" . $c["nombrejuego"] . " " .
                    $c["plat$p"] . ".png' width='350px' height='350px'></div>";
            }
        }
        echo "</div><a class='carousel-control-prev' href='#cc' data-slide='prev'></a>
            <a class='carousel-control-next' href='#cc' data-slide='next'></a></div></td><td bgcolor='lightgreen'>Género/s: " .
            $c["genero"] . "<br><br>Desarrollador: " . $c["desarrollador"] . "<br><br>Editor: " . $c["editor"] . "</td>";
        if ($c["NPC"] == "Ninguno Mas") {
            echo "<td bgcolor='lightblue' colspan='2'>" . $c["pjugable"] . "<br><br><Img src='imgpersonajes/"
                . $c["pjugable"] . ".png' width='350px' height='350px'></td>";
        }
        if ($c["pjugable"] == "Ninguno Mas") {
            echo "<td bgcolor='orange' colspan='2'>NPC: " . $c["NPC"] . " (" . $c["tipoNPC"] .
            ")<br><br><Img src='imgpersonajes/" . $c["NPC"] . ".png' width='350px' height='350px'></td></tr>";
        }
        if ($c["pjugable"] != "Ninguno Mas" && $c["NPC"] != "Ninguno Mas") {
            echo "<td bgcolor='lightblue'>" . $c["pjugable"] . "<br><br><Img src='imgpersonajes/" .
                $c["pjugable"] . ".png' width='350px' height='350px'></td><td bgcolor='orange'>
                <div id='cc' class='carousel slide' data-ride='carousel'>
                <div class='carousel-inner'><div class='carousel-item active'>NPC: " . $c["NPC"] . " (" .
                $c["tipoNPC"] . ")<br><br><Img src='imgpersonajes/" . $c["NPC"] .
                ".png' width='350px' height='350px'></div>";
        } echo "</div></td></tr>";
    } echo "</table>";
} ?> </body>

</html>
