<!doctype html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <title>Buscar Videojuegos Sonic</title>
    <link rel='stylesheet' href='https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css'>
    <link rel="stylesheet" href="../ModelosEstilos/CSS2.css">
    <script src='https://code.jquery.com/jquery-3.2.1.slim.min.js'></script>
    <script src='https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js'></script>
</head>

<body>
    <form action='S02.php' method='post' style="margin-top: 10px; text-align: center;">
        <input type="text" name="nombrejuego" placeholder="Juego">
        <input type="text" name="plat" placeholder="Plataforma"> <input type="text" name="genero" placeholder="Genero">
        <input type="text" name="tipoNPC" placeholder="Tipo NPC"><br><br>
        <input type="submit" name="buscarjuego" value="Buscar Videojuego">
    </form> <?php try { if (isset($_POST["buscarjuego"])) { $con = new PDO("mysql:host=localhost; dbname=sonicdb", "root", "");
        $con->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION); $con->exec("set character set utf8");
        $res = $con->prepare("SELECT * FROM videojuegos WHERE nombrejuego=? OR plat1=? OR plat2=? OR plat3=? OR genero=?
            OR tipoNPC=?"); $plat = $_POST["plat"]; $res->bindParam(1, $_POST["nombrejuego"]); $res->bindParam(2, $plat);
        $res->bindParam(3, $plat); $res->bindParam(4, $plat); $res->bindParam(5, $_POST["genero"]);
        $res->bindParam(6, $_POST["tipoNPC"]); $res->execute();
        echo "<table style='text-align: center'><tr><th>Videojuego y plat/s</th><th>Género, Desarrollador y Editor</th>
        <th colspan='2'>Personaje Jugable y/o No Jugable (NPC)</th></tr>";
        while ($c = $res->fetch(PDO::FETCH_ASSOC)) {
            echo "<tr><td><div id='cc' class='carousel slide' data-ride='carousel'>" . $c["nombrejuego"] .
                "<br><div class='carousel-inner'><div class='carousel-item active'>" . $c["plat1"] .
                "<br><br><img src='imgjuegos/" . $c["nombrejuego"] . " " . $c["plat1"] . ".png' width='350px' height='350px'></div>";
            for ($p = 2; $p < 17; $p++) {
                if ($c["plat$p"] != "No") {
                    echo "<div class='carousel-item'>" . $c["plat$p"] . "<br><br><img src='imgjuegos/" . $c["nombrejuego"] . " " .
                    $c["plat$p"] . ".png' width='350px' height='350px'></div>";
                }
            }
            echo "</div><a class='carousel-control-prev' href='#cc' data-slide='prev'></a>
                <a class='carousel-control-next' href='#cc' data-slide='next'></a></div></td><td bgcolor='lightgreen'>Género/s: " .
                $c["genero"] . "<br><br>Desarrollador: " . $c["desarrollador"] . "<br><br>Editor: " . $c["editor"] . "</td>";
            if ($c["NPC"] == "Ninguno Mas") {
                echo "<td bgcolor='lightblue' colspan='2'>" . $c["pjugable"] . "<br><br><Img src='imgpersonajes/"
                    . $c["pjugable"] . ".png' width='350px' height='350px'></td>";
            }
            if ($c["pjugable"] == "Ninguno Mas") {
                echo "<td bgcolor='orange' colspan='2'>NPC: " . $c["NPC"] . " (" . $c["tipoNPC"] .
                ")<br><br><Img src='imgpersonajes/" . $c["NPC"] . ".png' width='350px' height='350px'></td></tr>";
            }
            if ($c["pjugable"] != "Ninguno Mas" && $c["NPC"] != "Ninguno Mas") {
                echo "<td bgcolor='lightblue'>" . $c["pjugable"] . "<br><br><Img src='imgpersonajes/" .
                    $c["pjugable"] . ".png' width='350px' height='350px'></td><td bgcolor='orange'>
                    <div id='cc' class='carousel slide' data-ride='carousel'>
                    <div class='carousel-inner'><div class='carousel-item active'>NPC: " . $c["NPC"] . " (" .
                    $c["tipoNPC"] . ")<br><br><Img src='imgpersonajes/" . $c["NPC"] .
                    ".png' width='350px' height='350px'></div>";
            } echo "</div></td></tr>";
        } echo "</table>"; $res->closeCursor();
    }
} catch (Exception $e) { echo "¡Error! " . $e->getMessage(); } finally { $con = null; } ?> </body>

</html>
