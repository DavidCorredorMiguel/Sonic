<!doctype html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <title>Buscar Zonas Sonic</title>
    <link rel='stylesheet' href='https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css'>
    <link rel="stylesheet" href="../ModelosEstilos/CSS2.css">
    <script src='https://code.jquery.com/jquery-3.2.1.slim.min.js'></script>
    <script src='https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js'></script>
</head>

<body>
    <form action='S08.php' method='post' style="margin-top: 10px; text-align: center;">
        <input type="text" name="nz" placeholder="Nº Zona"> <input type="text" name="zona" placeholder="Zona">
        <input type="text" name="aparicion" placeholder="Juego"> <input type="text" name="isla" placeholder="Isla">
        <br><br><input type="submit" name="buscarzona" value="Buscar Zona">
    </form> <?php try { if (isset($_POST["buscarzona"])) { $con = new PDO("mysql:host=localhost; dbname=sonicdb", "root", "");
        $con->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION); $con->exec("set character set utf8");
        $res = $con->prepare("SELECT * FROM zonas WHERE nz=? OR zona=? OR aparicion1=? OR isla=?");
        $res->bindParam(1, $_POST["nz"]); $res->bindParam(2, $_POST["zona"]); $res->bindParam(3, $_POST["aparicion"]);
        $res->bindParam(4, $_POST["isla"]); $res->execute();
        echo "<table style='text-align: center'><tr><th>Zona</th><th>Aparicion</th><th>Isla</th></tr>";
        while ($c = $res->fetch(PDO::FETCH_ASSOC)) {
            echo "<tr><td id='ng'><div id='cc' class='carousel slide' data-ride='carousel'>" . $c["zona"] . "<br><br>Nº Zona: " .
                $c["nz"] . " (" . $c["act"] . " Acto/s)<div id='cc' class='carousel slide' data-ride='carousel'><br>
                <div class='carousel-inner'><div class='carousel-item active'>Act 1<br><br><img src='imgzonas/" . $c["zona"] .
                " Act 1.png' width='475px' height='475px'></div>";
            for ($p = 2; $p < 15; $p++) {
                if ($c["a$p"] != "No") {
                    echo "<div class='carousel-item'>Act " . $c["a$p"]."<br><br><img src='imgzonas/" . $c["zona"] . " Act " .
                        $c["a$p"] . ".png' width='475px' height='475px'></div>";
                }
            }
            echo "</div><a class='carousel-control-prev' href='#cc' data-slide='prev'></a>
                <a class='carousel-control-next' href='#cc' data-slide='next'></a></div></td><td bgcolor='lightgreen'>" .
                $c["aparicion1"]. "<br><br><img src='imgseriepelilogo/" . $c["aparicion1"] . ".png' width='475px' height='475px'>";
            if ($c["isla"] != "Desconocida"){
                echo "</td><td bgcolor='orange'>" . $c["isla"]. "<br><br><img src='imgzonas/" . $c["isla"] .
                    ".png' width='475px' height='475px'>";
            } else {
                echo "</td><td bgcolor='orange'>" . $c["isla"]. "<br><br><img src='imgseriepelilogo/" . $c["aparicion1"] .
                    ".png' width='475px' height='475px'>";
            } echo "</td></tr>";
        } echo "</table>"; $res->closeCursor();
    }
} catch (Exception $e) { echo "¡Error! " . $e->getMessage(); } finally { $con = null; } ?> </body>

</html>
