<!doctype html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <title>Musica Zonas De Sonic</title>
    <link rel='stylesheet' href='https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css'>
    <link rel="stylesheet" href="../ModelosEstilos/CSS2.css">
    <script src='https://code.jquery.com/jquery-3.2.1.slim.min.js'></script>
    <script src='https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js'></script>
</head>

<body> <?php $con = new mysqli("localhost", "root", "", "sonicdb"); if (!($res = $con->stmt_init())) { die(mysqli_connect_error());}
if (!isset($_GET["pag"])) { $pag = 1; } else { $pag = $_GET["pag"]; } $resultadopag = 50;
$res->prepare("select count(*) as 'total' from musicazonas"); $res->execute(); $res->bind_result($total);
$fila = $res->fetch(); $numpag = ceil($total / $resultadopag); $pagactual = ($pag - 1) * $resultadopag;
$res->prepare("select * from musicazonas LIMIT " . $pagactual . ", " . $resultadopag); $res->execute();
$res->bind_result($idz, $nz, $zonacancion, $cancionjuego, $cact1, $artistac1, $cact2, $artistac2, $cact3, $artistac3, $cact4,
$artistac4, $cact5, $artistac5, $cact6, $artistac6, $cact7, $artistac7);
echo "<table style='text-align: center'><tr><th>Zona</th><th>Juego</th><th>Musica y Artista/s</th></tr>";
while ($res->fetch()) {
    echo "<tr><td id='ng'>" . $zonacancion . "<br><br>Nº Zona: " . $nz . "<img src='imgzonas/" .
        $zonacancion . " Act 1.png' width='350px' height='350px'></td><td>" . $cancionjuego . "<br><br><img src='imgseriepelilogo/" .
        $cancionjuego . ".png' width='300px' height='300px'></td><td id='ng'><div id='cc' class='carousel slide' data-ride='carousel'>
        <div class='carousel-inner'><div class='carousel-item active'>";
    if ($cact1 != "No") { echo "Artista/s: " . $artistac1 . "<br>";
        if ($cact1 != "Act 1"){ echo "Cancion: " . $cact1 . "<br><audio src='musica/" . $cact1; }
        else { echo "Cancion: " . $zonacancion . " Act 1<br><audio src='musica/" . $zonacancion . " Act 1"; }
        echo ".oga' style='width: 250px;' controls=''></audio>";
    } else { echo ""; }
    echo "<br><img src='imgzonas/" . $zonacancion . " Act 1.png' width='300px' height='300px'></div><div class='carousel-item'>";
    if ($cact2 != "No") { echo "Artista/s: " . $artistac2 . "<br>";
        if ($cact2 != "Act 2"){ echo "Cancion: " . $cact2 . "<br><audio src='musica/" . $cact2; }
        else { echo "Cancion: " . $zonacancion . " Act 2<br><audio src='musica/" . $zonacancion . " Act 2"; }
        echo ".oga' style='width: 250px;' controls=''></audio><br><img src='imgzonas/" . $zonacancion .
            " Act 2.png' width='300px' height='300px'></div>";
    } else { echo "<img src='imgseriepelilogo/" . $cancionjuego . ".png' width='300px' height='300px'></div>"; }
    echo "<div class='carousel-item'>";
    if ($cact3 != "No") { echo "Artista/s: " . $artistac3 . "<br>";
        if ($cact3 != "Act 3"){ echo "Cancion: " . $cact3 . "<br><audio src='musica/" . $cact3; }
        else { echo "Cancion: " . $zonacancion . " Act 3<br><audio src='musica/" . $zonacancion . " Act 3"; }
        echo ".oga' style='width: 250px;' controls=''></audio><br><img src='imgzonas/" . $zonacancion .
            " Act 3.png' width='300px' height='300px'></div>";
    } else { echo "<img src='imgseriepelilogo/" . $cancionjuego . ".png' width='300px' height='300px'></div>"; }
    echo "<div class='carousel-item'>";
    if ($cact4 != "No") { echo "Artista/s: " . $artistac4 . "<br>";
        if ($cact4 != "Act 4"){ echo "Cancion: " . $cact4 . "<br><audio src='musica/" . $cact4; }
        else { echo "Cancion: " . $zonacancion . " Act 4<br><audio src='musica/" . $zonacancion . " Act 4"; }
        echo ".oga' style='width: 250px;' controls=''></audio><br><img src='imgzonas/" . $zonacancion .
            " Act 4.png' width='300px' height='300px'></div>";
    } else { echo "<img src='imgseriepelilogo/" . $cancionjuego . ".png' width='300px' height='300px'></div>"; }
    echo "<div class='carousel-item'>";
    if ($cact5 != "No") { echo "Artista/s: " . $artistac5 . "<br>";
        if ($cact5 != "Act 5"){ echo "Cancion: " . $cact5 . "<br><audio src='musica/" . $cact5; }
        else { echo "Cancion: " . $zonacancion . " Act 5<br><audio src='musica/" . $zonacancion . " Act 5"; }
        echo ".oga' style='width: 250px;' controls=''></audio><br><img src='imgzonas/" . $zonacancion .
            " Act 5.png' width='300px' height='300px'></div>";
    } else { echo "<img src='imgseriepelilogo/" . $cancionjuego . ".png' width='300px' height='300px'></div>"; }
    echo "<div class='carousel-item'>";
    if ($cact6 != "No") { echo "Artista/s: " . $artistac6 . "<br>";
        if ($cact6 != "Act 6"){ echo "Cancion: " . $cact6 . "<br><audio src='musica/" . $cact6; }
        else { echo "Cancion: " . $zonacancion . " Act 6<br><audio src='musica/" . $zonacancion . " Act 6"; }
        echo ".oga' style='width: 250px;' controls=''></audio><br><img src='imgzonas/" . $zonacancion .
            " Act 6.png' width='300px' height='300px'></div>";
    } else { echo "<img src='imgseriepelilogo/" . $cancionjuego . ".png' width='300px' height='300px'></div>"; }
    echo "<div class='carousel-item'>";
    if ($cact7 != "No") { echo "Artista/s: " . $artistac7 . "<br>";
        if ($cact7 != "Act 7"){ echo "Cancion: " . $cact7 . "<br><audio src='musica/" . $cact7; }
        else { echo "Cancion: " . $zonacancion . " Act 7<br><audio src='musica/" . $zonacancion . " Act 7"; }
        echo ".oga' style='width: 250px;' controls=''></audio><br><img src='imgzonas/" . $zonacancion .
            " Act 7.png' width='300px' height='300px'></div>";
    } else { echo "<img src='imgseriepelilogo/" . $cancionjuego . ".png' width='300px' height='300px'></div>"; }
    echo "<a class='carousel-control-prev' href='#cc' data-slide='prev'></a>
        <a class='carousel-control-next' href='#cc' data-slide='next'></a></div></td></tr>";
} echo "</table><br><br><div id='pag' style='text-align: center'>";
if ($pag != 1) { echo " <a href='S18.php?pag=" . ($pag - 1) . "'><</a> <a href='S18.php?pag=1'>1</a> "; }
for ($i = $pag - 1; $i < $pag + 2; $i++) { if ($i > 1 && $i <= $numpag) { echo " <a href='S18.php?pag=" . $i . "'>$i</a> "; } }
if ($pag != $numpag) { echo " ... <a href='S18.php?pag=$numpag'>$numpag</a> <a href='S18.php?pag=" . ($pag + 1) . "'>></a>"; }
echo "<br><br></div>"; $res->close(); ?> </body>

</html>
