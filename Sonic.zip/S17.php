<!doctype html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <title>Buscar Musica Zonas Sonic</title>
    <link rel='stylesheet' href='https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css'>
    <link rel="stylesheet" href="../ModelosEstilos/CSS2.css">
    <script src='https://code.jquery.com/jquery-3.2.1.slim.min.js'></script>
    <script src='https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js'></script>
</head>

<body>
    <form action='S17.php' method='post' style="margin-top: 10px; text-align: center;">
        <input type="text" name="nz" placeholder="Nº Zona"> <input type="text" name="zona" placeholder="Zona">
        <input type="text" name="aparicion" placeholder="Juego"> <input type="text" name="cact" placeholder="Tema Zona">
        <input type="text" name="artista" placeholder="Artista Zona"><br><br>
        <input type="submit" name="buscarmusicazona" value="Buscar Musica Zona">
    </form> <?php try { if (isset($_POST["buscarmusicazona"])) { $con = new PDO("mysql:host=localhost; dbname=sonicdb", "root", "");
        $con->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION); $con->exec("set character set utf8");
        $res = $con->prepare("SELECT * FROM musicazonas WHERE nz=? OR zonacancion=? OR cancionjuego=? OR cact1=? OR cact2=?
            OR cact3=? OR cact4=? OR cact5=? OR cact6=? OR cact7=? OR artistac1=? OR artistac2=? OR artistac3=? OR artistac4=?
            OR artistac5=? OR artistac6=? OR artistac7=?"); $cact = $_POST["cact"]; $artista = $_POST["artista"];
        $res->bindParam(1, $_POST["nz"]); $res->bindParam(2, $_POST["zona"]); $res->bindParam(3, $_POST["cancionjuego"]);
        $res->bindParam(4, $cact); $res->bindParam(5, $cact); $res->bindParam(6, $cact); $res->bindParam(7, $cact);
        $res->bindParam(8, $cact); $res->bindParam(9, $cact); $res->bindParam(10, $cact); $res->bindParam(11, $artista);
        $res->bindParam(12, $artista); $res->bindParam(13, $artista); $res->bindParam(14, $artista); $res->bindParam(15, $artista);
        $res->bindParam(16, $artista); $res->bindParam(17, $artista); $res->execute();
        echo "<table style='text-align: center'><tr><th>Zona</th><th>Juego</th><th>Musica y Artista/s</th></tr>";
        while ($c = $res->fetch(PDO::FETCH_ASSOC)) {
            echo "<tr><td id='ng'>" . $c["zonacancion"] . "<br><br>Nº Zona: " . $c["nz"] .
                "<img src='imgzonas/" . $c["zonacancion"] . " Act 1.png' width='350px' height='350px'></td><td>" .
                $c["cancionjuego"] . "<br><br><img src='imgseriepelilogo/" . $c["cancionjuego"] .
                ".png' width='300px' height='300px'></td><td id='ng'><div id='cc' class='carousel slide' data-ride='carousel'>
                <div class='carousel-inner'><div class='carousel-item active'>";
            if ($c["cact1"] != "No") { echo "Artista/s: " . $c["artistac1"] . "<br>";
                if ($c["cact1"] != "Act 1"){ echo "Cancion: " . $c["cact1"] . "<br><audio src='musica/" . $c["cact1"]; }
                else { echo "Cancion: " . $c["zonacancion"] . " Act 1<br><audio src='musica/" . $c["zonacancion"] . " Act 1"; }
                echo ".oga' style='width: 250px;' controls=''></audio>";
            } else { echo ""; } echo "<br><img src='imgzonas/" . $c["zonacancion"] ." Act 1.png' width='300px' height='300px'></div>";
            for ($p = 2; $p < 8; $p++) { echo "<div class='carousel-item'>";
                if ($c["cact$p"] != "No") { echo "Artista/s: " . $c["artistac$p"] . "<br>";
                    if ($c["cact$p"] != "Act $p"){ echo "Cancion: " . $c["cact$p"]."<br><audio src='musica/".$c["cact$p"]; }
                    else {echo "Cancion: " . $c["zonacancion"]." Act $p"."<br><audio src='musica/".$c["zonacancion"]." Act $p"; }
                    echo ".oga' style='width: 250px;' controls=''></audio><br><img src='imgzonas/" . $c["zonacancion"] .
                        " Act $p.png' width='300px' height='300px'>";
                } else { echo "<img src='imgseriepelilogo/".$c["cancionjuego"].".png' width='300px' height='300px'>"; } echo "</div>";
            }
            echo "<a class='carousel-control-prev' href='#cc' data-slide='prev'></a>
                <a class='carousel-control-next' href='#cc' data-slide='next'></a></div></td></tr>";
        } echo "</table>"; $res->closeCursor();
    }
} catch (Exception $e) { echo "¡Error! " . $e->getMessage(); } finally { $con = null; } ?> </body>

</html>
