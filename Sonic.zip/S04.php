<!doctype html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <title>Series/Pelis De Sonic</title>
    <link rel="stylesheet" href="../ModelosEstilos/CSS2.css">
</head>

<body> <?php require_once "../ModelosEstilos/SonicM02.php"; $m = new SonicM02(); $v = array();
if (isset($_POST["seriepeli"])) { $v = $m->getseriepeli(); } if (isset($_POST["genero"])) { $v = $m->getGenero(); }
if (isset($_POST["b1"])) { $v = $m->getSerie(); } if (isset($_POST["b2"])) { $v = $m->getPeli(); }
echo "<br><form action='S04.php' method='post'><select name='seriepeliv'>";
foreach ($m->sacaSeriePeli() as $seriepeli) { echo "<option value='$seriepeli'>" . $seriepeli . "</option>"; }
echo "</select><input type='submit' value='Buscar Serie/Peli' name='seriepeli'><select name='generov'>";
foreach ($m->sacaGenero() as $genero) { echo "<option value='$genero'>" . $genero . "</option>"; }
echo "</select><input type='submit' value='Buscar Genero' name='genero'><select name='tempv'>";
foreach ($m->sacaTemp() as $temp) { echo "<option value='$temp'>Cantidad De Temporadas: " . $temp . "</option>"; }
echo "</select><input type='submit' value='Buscar Temporadas' name='temp'><input type='submit' name='b1' value='Series'>
<input type='submit' name='b2' value='Peliculas'></form><br>";
if (isset($_POST["seriepeli"]) || isset($_POST["genero"]) || isset($_POST["temp"]) || isset($_POST["b1"]) || isset($_POST["b2"])) {
    echo "<table style='text-align: center'><tr><th>Serie/Peli</th><th>Género/s</th>
    <th>Nª Temporadas y Episodios, Duración, Estreno y Fecha Fin (Serie)</th><th>Personajes</th></tr>";
    foreach ($v as $c) {
        echo "<tr><td>" . $c["nombre"] . " (" . $c["tipo"] . ")<br><br><img src='imgseriepelilogo/" .
            $c["nombre"] . ".png' width='450px' height='450px'></td><td bgcolor='lightgreen'>" . $c["genero1"];
        if ($c["genero2"] != "No") { echo "<br><br>" . $c["genero2"]; } if ($c["genero3"] != "No") { echo "<br><br>" . $c["genero3"]; }
        echo "</td><td bgcolor='orange'>"; if ($c["temp"] != "No") { echo "<br><br>Nª Temporadas: " . $c["temp"]; }
        if ($c["nep"] != "No") { echo "<br><br>Nª Episodios: " . $c["nep"]; }
        echo "<br><br>Duración (Episodios o Pelicula): " . $c["min"] . " Minutos<br><br>Estreno: " . $c["estreno"];
        if ($c["fechafin"] != "No") { echo "<br><br>Fecha Fin (Serie): " . $c["fechafin"]; }
        echo "</td><td>" . $c["personajes"] . "<br><br><img src='imgpersonajes/" . $c["personajes"] .
            ".png' width='450px' height='450px'></td></tr>";
    } echo "</table>";
} ?> </body>

</html>