<!doctype html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <title>Series/Pelis De Sonic</title>
    <link rel="stylesheet" href="../ModelosEstilos/CSS2.css">
</head>

<body> <?php $con = new mysqli("localhost", "root", "", "sonicdb"); if (!($res = $con->stmt_init())) { die(mysqli_connect_error());}
if (!isset($_GET["pag"])) { $pag = 1; } else { $pag = $_GET["pag"]; } $resultadopag = 50;
$res->prepare("select count(*) as 'total' from seriesypelis"); $res->execute(); $res->bind_result($total);
$fila = $res->fetch(); $numpag = ceil($total / $resultadopag); $pagactual = ($pag - 1) * $resultadopag;
$res->prepare("select * from seriesypelis LIMIT " . $pagactual . ", " . $resultadopag); $res->execute();
$res->bind_result($idsp, $tipo, $nombre, $genero1, $genero2, $genero3, $temp, $nep, $min, $estreno, $fechafin, $personajes);
echo "<table style='text-align: center'><tr><th>Serie/Peli</th><th>Género/s</th>
    <th>Nª Temporadas y Episodios, Duración, Estreno y Fecha Fin (Serie)</th><th>Personajes</th></tr>";
while ($res->fetch()) {
    echo "<tr><td>" . $nombre . " (" . $tipo . ")<br><br><img src='imgseriepelilogo/" . $nombre . ".png' width='450px' height='450px'>
    </td><td bgcolor='lightgreen'>" . $genero1; if ($genero2 != "No") { echo "<br><br>" . $genero2; }
    if ($genero3 != "No") { echo "<br><br>" . $genero3; } echo "</td><td bgcolor='orange'>";
    if ($temp != "No") { echo "<br><br>Nª Temporadas: " . $temp; } if ($nep != "No") { echo "<br><br>Nª Episodios: " . $nep; }
    echo "<br><br>Duración (Episodios o Pelicula): " . $min . " Minutos<br><br>Estreno: " . $estreno;
    if ($fechafin != "No") { echo "<br><br>Fecha Fin (Serie): " . $fechafin; }
    echo "</td><td>" . $personajes . "<br><br><img src='imgpersonajes/" . $personajes . ".png' width='450px' height='450px'></td></tr>";
} echo "</table><br><br><div id='pag' style='text-align: center'>";
if ($pag != 1) { echo " <a href='S06.php?pag=" . ($pag - 1) . "'><</a> <a href='S06.php?pag=1'>1</a> "; }
for ($i = $pag - 1; $i < $pag + 2; $i++) { if ($i > 1 && $i <= $numpag) { echo " <a href='S06.php?pag=" . $i . "'>$i</a> "; } }
if ($pag != $numpag) { echo " ... <a href='S06.php?pag=$numpag'>$numpag</a> <a href='S06.php?pag=" . ($pag + 1) . "'>></a>"; }
echo "<br><br></div>"; $res->close(); ?> </body>

</html>
