<!doctype html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <title>Musica Zonas De Sonic</title>
    <link rel='stylesheet' href='https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css'>
    <link rel="stylesheet" href="../ModelosEstilos/CSS2.css">
    <script src='https://code.jquery.com/jquery-3.2.1.slim.min.js'></script>
    <script src='https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js'></script>
</head>

<body> <?php $con = new mysqli("localhost", "root", "", "sonicdb"); if (!($res = $con->stmt_init())) { die(mysqli_connect_error());}
if (!isset($_GET["pag"])) { $pag = 1; } else { $pag = $_GET["pag"]; } $resultadopag = 50;
$res->prepare("select count(*) as 'total' from musicajefes"); $res->execute(); $res->bind_result($total);
$fila = $res->fetch(); $numpag = ceil($total / $resultadopag); $pagactual = ($pag - 1) * $resultadopag;
$res->prepare("select * from musicajefes LIMIT " . $pagactual . ", " . $resultadopag); $res->execute();
$res->bind_result($idz, $nz, $zonacancion, $cancionjuego, $jefe1, $cjefe1, $artistaj1, $jefe2, $cjefe2, $artistaj2, $jefe3, $cjefe3,
$artistaj3, $jefe4, $cjefe4, $artistaj4, $jefe5, $cjefe5, $artistaj5, $jefe6, $cjefe6, $artistaj6, $jefe7, $cjefe7, $artistaj7, $jefe8,
$cjefe8, $artistaj8); echo "<table style='text-align: center'><tr><th>Zona</th><th>Juego</th><th>Musica y Artista/s</th></tr>";
while ($res->fetch()) {
    echo "<tr><td bgcolor='black'><p style='color: white'>" . $zonacancion . "<br><br>Nº Zona: " . $nz . "</p><img src='imgzonas/" .
        $zonacancion . " Act 1.png' width='350px' height='350px'></td><td>" . $cancionjuego . "<br><br><img src='imgseriepelilogo/" .
        $cancionjuego . ".png' width='300px' height='300px'></td><td bgcolor='black' style='color: white'>
        <div id='cc' class='carousel slide' data-ride='carousel'>
        <div class='carousel-inner'><div class='carousel-item active'>";
    if ($cjefe1 != "No") {
        echo "Artista/s: " . $artistaj1 . "<br>Jefe: " . $jefe1 . "<br>Cancion: " . $cjefe1 . "<br><audio src='musica/Jefe " .
            $cjefe1 . ".oga' style='width: 250px;' controls=''></audio><br><img src='imgrobotsyjefes/" . $jefe1 .
            ".png' width='300px' height='300px'>";
    } else { echo "<br><img src='imgseriepelilogo/" . $cancionjuego . ".png' width='300px' height='300px'>"; }
    echo "</div><div class='carousel-item'>";
    if ($cjefe2 != "No") {
        echo "Artista/s: " . $artistaj2 . "<br>Jefe: " . $jefe2 . "<br>Cancion: " . $cjefe2 . "<br><audio src='musica/Jefe " .
            $cjefe2 . ".oga' style='width: 250px;' controls=''></audio><br><img src='imgrobotsyjefes/" . $jefe2 .
            ".png' width='300px' height='300px'>";
    } else { echo "<br><img src='imgseriepelilogo/" . $cancionjuego . ".png' width='300px' height='300px'>"; }
    echo "</div><div class='carousel-item'>";
    if ($cjefe3 != "No") {
        echo "Artista/s: " . $artistaj3 . "<br>Jefe: " . $jefe3 . "<br>Cancion: " . $cjefe3 . "<br><audio src='musica/Jefe " .
            $cjefe3 . ".oga' style='width: 250px;' controls=''></audio><br><img src='imgrobotsyjefes/" . $jefe3 .
            ".png' width='300px' height='300px'>";
    } else { echo "<br><img src='imgseriepelilogo/" . $cancionjuego . ".png' width='300px' height='300px'>"; }
    echo "</div><div class='carousel-item'>";
    if ($cjefe4 != "No") {
        echo "Artista/s: " . $artistaj4 . "<br>Jefe: " . $jefe4 . "<br>Cancion: " . $cjefe4 . "<br><audio src='musica/Jefe " .
            $cjefe4 . ".oga' style='width: 250px;' controls=''></audio><br><img src='imgrobotsyjefes/" . $jefe4 .
            ".png' width='300px' height='300px'>";
    } else { echo "<br><img src='imgseriepelilogo/" . $cancionjuego . ".png' width='300px' height='300px'>"; }
    echo "</div><div class='carousel-item'>";
    if ($cjefe5 != "No") {
        echo "Artista/s: " . $artistaj5 . "<br>Jefe: " . $jefe5 . "<br>Cancion: " . $cjefe5 . "<br><audio src='musica/Jefe " .
            $cjefe5 . ".oga' style='width: 250px;' controls=''></audio><br><img src='imgrobotsyjefes/" . $jefe5 .
            ".png' width='300px' height='300px'>";
    } else { echo "<br><img src='imgseriepelilogo/" . $cancionjuego . ".png' width='300px' height='300px'>"; }
    echo "</div><div class='carousel-item'>";
    if ($cjefe6 != "No") {
        echo "Artista/s: " . $artistaj6 . "<br>Jefe: " . $jefe6 . "<br>Cancion: " . $cjefe6 . "<br><audio src='musica/Jefe " .
            $cjefe6 . ".oga' style='width: 250px;' controls=''></audio><br><img src='imgrobotsyjefes/" . $jefe6 .
            ".png' width='300px' height='300px'>";
    } else { echo "<br><img src='imgseriepelilogo/" . $cancionjuego . ".png' width='300px' height='300px'>"; }
    echo "</div><div class='carousel-item'>";
    if ($cjefe7 != "No") {
        echo "Artista/s: " . $artistaj7 . "<br>Jefe: " . $jefe7 . "<br>Cancion: " . $cjefe7 . "<br><audio src='musica/Jefe " .
            $cjefe7 . ".oga' style='width: 250px;' controls=''></audio><br><img src='imgrobotsyjefes/" . $jefe7 .
            ".png' width='300px' height='300px'>";
    } else { echo "<br><img src='imgseriepelilogo/" . $cancionjuego . ".png' width='300px' height='300px'>"; }
    echo "</div><div class='carousel-item'>";
    if ($cjefe8 != "No") {
        echo "Artista/s: " . $artistaj8 . "<br>Jefe: " . $jefe8 . "<br>Cancion: " . $cjefe8 . "<br><audio src='musica/Jefe " .
            $cjefe8 . ".oga' style='width: 250px;' controls=''></audio><br><img src='imgrobotsyjefes/" . $jefe8 .
            ".png' width='300px' height='300px'></div>";
    }
    echo "<a class='carousel-control-prev' href='#cc' data-slide='prev'></a>
        <a class='carousel-control-next' href='#cc' data-slide='next'></a></div></td></tr>";
} echo "</table><br><br><div id='pag' style='text-align: center'>";
if ($pag != 1) { echo " <a href='S18.php?pag=" . ($pag - 1) . "'><</a> <a href='S18.php?pag=1'>1</a> "; }
for ($i = $pag - 1; $i < $pag + 2; $i++) { if ($i > 1 && $i <= $numpag) { echo " <a href='S18.php?pag=" . $i . "'>$i</a> "; } }
if ($pag != $numpag) { echo " ... <a href='S18.php?pag=$numpag'>$numpag</a> <a href='S18.php?pag=" . ($pag + 1) . "'>></a>"; }
echo "<br><br></div>"; $res->close(); ?> </body>

</html>