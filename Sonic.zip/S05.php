<!doctype html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <title>Buscar Series/Pelis Sonic</title>
    <link rel="stylesheet" href="../ModelosEstilos/CSS2.css">
</head>

<body>
    <form action='S05.php' method='post' style="margin-top: 10px; text-align: center;">
        <input type="text" name="nombre" placeholder="Serie/Peli">
        <input type="text" name="genero" placeholder="Genero"> <input type="text" name="temp" placeholder="Temporada">
        <input type="text" name="personajes" placeholder="Personaje">
        <br><br><input type="submit" name="buscarseriepeli" value="Buscar Serie/Peli">
    </form> <?php try { if (isset($_POST["buscarseriepeli"])) { $con = new PDO("mysql:host=localhost; dbname=sonicdb", "root", "");
        $con->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION); $con->exec("set character set utf8");
        $res = $con->prepare("SELECT * FROM seriesypelis WHERE nombre=? OR genero1=? OR genero2=? OR genero3=? OR temp=?
            OR personajes=?"); $genero = $_POST["genero"]; $res->bindParam(1, $_POST["nombre"]); $res->bindParam(2, $genero);
        $res->bindParam(3, $genero); $res->bindParam(4, $genero); $res->bindParam(5, $_POST["temp"]);
        $res->bindParam(6, $_POST["personajes"]); $res->execute();
        echo "<table style='text-align: center'><tr><th>Serie/Peli</th><th>Género/s</th>
            <th>Nª Temporadas y Episodios, Duración, Estreno y Fecha Fin (Serie)</th><th>Personajes</th></tr>";
        while ($c = $res->fetch(PDO::FETCH_ASSOC)) {
            echo "<tr><td>" . $c["nombre"] . " (" . $c["tipo"] . ")<br><br><img src='imgseriepelilogo/" .
            $c["nombre"] . ".png' width='450px' height='450px'></td><td bgcolor='lightgreen'>" . $c["genero1"];
            if ($c["genero2"] != "No") { echo "<br><br>" . $c["genero2"]; }
            if ($c["genero3"] != "No") { echo "<br><br>" . $c["genero3"]; }
            echo "</td><td bgcolor='orange'>"; if ($c["temp"] != "No") { echo "<br><br>Nª Temporadas: " . $c["temp"]; }
            if ($c["nep"] != "No") { echo "<br><br>Nª Episodios: " . $c["nep"]; }
            echo "<br><br>Duración (Episodios o Pelicula): " . $c["min"] . " Minutos<br><br>Estreno: " . $c["estreno"];
            if ($c["fechafin"] != "No") { echo "<br><br>Fecha Fin (Serie): " . $c["fechafin"]; }
            echo "</td><td>" . $c["personajes"] . "<br><br><img src='imgpersonajes/" . $c["personajes"] .
                ".png' width='450px' height='450px'></td></tr>";
        } echo "</table>"; $res->closeCursor();
    }
} catch (Exception $e) { echo "¡Error! " . $e->getMessage(); } finally { $con = null; } ?> </body>

</html>
