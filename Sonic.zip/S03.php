<!doctype html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <title>Videojuegos De Sonic</title>
    <link rel='stylesheet' href='https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css'>
    <link rel="stylesheet" href="../ModelosEstilos/CSS2.css">
    <script src='https://code.jquery.com/jquery-3.2.1.slim.min.js'></script>
    <script src='https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js'></script>
</head>

<body> <?php $con = new mysqli("localhost", "root", "", "sonicdb"); if (!($res = $con->stmt_init())) { die(mysqli_connect_error());}
if (!isset($_GET["pag"])) { $pag = 1; } else { $pag = $_GET["pag"]; } $resultadopag = 100;
$res->prepare("select count(*) as 'total' from videojuegos"); $res->execute();
$res->bind_result($total); $fila = $res->fetch(); $numpag = ceil($total / $resultadopag);
$pagactual = ($pag - 1) * $resultadopag; $res->prepare("select * from videojuegos LIMIT " . $pagactual . ", " . $resultadopag);
$res->execute(); $res->bind_result($idj, $nombrejuego, $plat1, $plat2, $plat3, $plat4, $plat5, $plat6, $plat7, $plat8, $plat9, $plat10,
$plat11, $plat12, $plat13, $plat14, $plat15, $plat16, $genero, $desarrollador, $editor, $pjugable, $tipoNPC, $NPC);
echo "<table style='text-align: center'><tr><th>Videojuego y plat/s</th><th>Género, Desarrollador y Editor</th>
<th colspan='2'>Personaje Jugable y/o No Jugable (NPC)</th></tr>";
while ($res->fetch()) {
    echo "<tr><td><div id='cc' class='carousel slide' data-ride='carousel'>" .
        $nombrejuego . "<br><div class='carousel-inner'><div class='carousel-item active'>"
        . $plat1 . "<br><br><img src='imgjuegos/" . $nombrejuego . " " . $plat1 . ".png' width='350px' height='350px'></div>";
    if ($plat2 != "No") {
        echo "<div class='carousel-item'>" . $plat2 . "<br><br><img src='imgjuegos/" . $nombrejuego . " " . $plat2 .
            ".png' width='350px' height='350px'></div>";
        if ($plat3 != "No") {
            echo "<div class='carousel-item'>" . $plat3 . "<br><br><img src='imgjuegos/" . $nombrejuego . " " . $plat3
             . ".png' width='350px' height='350px'></div>";
        }
    }
    if ($plat4 != "No") {
        echo "<div class='carousel-item'>" . $plat4 . "<br><br><img src='imgjuegos/" .
            $nombrejuego . " " . $plat4 . ".png' width='350px' height='350px'></div>";
        if ($plat5 != "No") {
            echo "<div class='carousel-item'>" . $plat5 . "<br><br><img src='imgjuegos/" . $nombrejuego . " " . $plat5
             . ".png' width='350px' height='350px'></div>";
        }
    }
    if ($plat6 != "No") {
        echo "<div class='carousel-item'>" . $plat6 . "<br><br><img src='imgjuegos/" . $nombrejuego . " " . $plat6 .
            ".png' width='350px' height='350px'></div>";
        if ($plat7 != "No") {
            echo "<div class='carousel-item'>" . $plat7 . "<br><br><img src='imgjuegos/" . $nombrejuego . " " . $plat7 . ".png' width='350px' height='350px'></div>";
        }
    }
    if ($plat8 != "No") {
        echo "<div class='carousel-item'>" . $plat8 . "<br><br><img src='imgjuegos/" . $nombrejuego . " " . $plat8 .
            ".png' width='350px' height='350px'></div>";
        if ($plat9 != "No") {
            echo "<div class='carousel-item'>" . $plat9 . "<br><br><img src='imgjuegos/" . $nombrejuego . " " . $plat9 . ".png' width='350px' height='350px'></div>";
        }
    }
    if ($plat10 != "No") {
        echo "<div class='carousel-item'>" . $plat10 . "<br><br><img src='imgjuegos/" . $nombrejuego . " " . $plat10 .
            ".png' width='350px' height='350px'></div>";
        if ($plat11 != "No") {
            echo "<div class='carousel-item'>" . $plat11 . "<br><br><img src='imgjuegos/" . $nombrejuego . " " . $plat11 . ".png' width='350px' height='350px'></div>";
        }
    }
    if ($plat12 != "No") {
        echo "<div class='carousel-item'>" . $plat12 . "<br><br><img src='imgjuegos/" . $nombrejuego . " " . $plat12 .
            ".png' width='350px' height='350px'></div>";
        if ($plat13 != "No") {
            echo "<div class='carousel-item'>" . $plat13 . "<br><br><img src='imgjuegos/" . $nombrejuego . " " . $plat13 . ".png' width='350px' height='350px'></div>";
        }
    }
    if ($plat14 != "No") {
        echo "<div class='carousel-item'>" . $plat14 . "<br><br><img src='imgjuegos/" . $nombrejuego . " " . $plat14 .
            ".png' width='350px' height='350px'></div>";
        if ($plat15 != "No") {
            echo "<div class='carousel-item'>" . $plat15 . "<br><br><img src='imgjuegos/" . $nombrejuego . " " . $plat15 . ".png' width='350px' height='350px'></div>";
        }
    }
    if ($plat16 != "No") {
        echo "<div class='carousel-item'>" . $plat16 . "<br><br><img src='imgjuegos/" . $nombrejuego . " " . $plat16 .
            ".png' width='350px' height='350px'></div>";
    }
    echo "</div><a class='carousel-control-prev' href='#cc' data-slide='prev'></a>
        <a class='carousel-control-next' href='#cc' data-slide='next'></a></div></td><td bgcolor='lightgreen'>Género/s: " . $genero .
        "<br><br>Desarrollador: " . $desarrollador . "<br><br>Editor: " . $editor . "</td>";
    if ($NPC == "Ninguno Mas") {
        echo "<td bgcolor='lightblue' colspan='2'>" . $pjugable . "<br><br><Img src='imgpersonajes/"
            . $pjugable . ".png' width='350px' height='350px'></td>";
    }
    if ($pjugable == "Ninguno Mas") {
        echo "<td bgcolor='orange' colspan='2'>NPC: " . $NPC . " (" . $tipoNPC . ")<br><br><Img src='imgpersonajes/" .
        $NPC . ".png' width='350px' height='350px'></td></tr>";
    }
    if ($pjugable != "Ninguno Mas" && $NPC != "Ninguno Mas") {
        echo "<td bgcolor='lightblue'>" . $pjugable . "<br><br><Img src='imgpersonajes/" .
            $pjugable . ".png' width='350px' height='350px'></td><td bgcolor='orange'>
            <div id='cc' class='carousel slide' data-ride='carousel'>
            <div class='carousel-inner'><div class='carousel-item active'>NPC: " . $NPC . " (" .
            $tipoNPC . ")<br><br><Img src='imgpersonajes/" . $NPC . ".png' width='350px' height='350px'></div>";
    } echo "</div></td></tr>";
} echo "</table><br><br><div id='pag' style='text-align: center'>";
if ($pag != 1) { echo " <a href='S03.php?pag=" . ($pag - 1) . "'><</a> <a href='S03.php?pag=1'>1</a> "; }
for ($i = $pag - 1; $i < $pag + 2; $i++) { if ($i > 1 && $i <= $numpag) { echo " <a href='S03.php?pag=" . $i . "'>$i</a> "; } }
if ($pag != $numpag) { echo " ... <a href='S03.php?pag=$numpag'>$numpag</a> <a href='S03.php?pag=" . ($pag + 1) . "'>></a>"; }
echo "<br><br></div>"; $res->close(); ?> </body>

</html>
