<!doctype html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <title>Zonas De Sonic</title>
    <link rel='stylesheet' href='https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css'>
    <link rel="stylesheet" href="../ModelosEstilos/CSS2.css">
    <script src='https://code.jquery.com/jquery-3.2.1.slim.min.js'></script>
    <script src='https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js'></script>
</head>

<body> <?php require_once "../ModelosEstilos/SonicM03.php"; $m = new SonicM03(); $v = array();
if (isset($_POST["nz"])) { $v = $m->getNZ(); } if (isset($_POST["zona"])) { $v = $m->getZona(); }
if (isset($_POST["aparicion"])) { $v = $m->getAparicion(); } if (isset($_POST["isla"])) { $v = $m->getIsla(); }
echo "<br><form action='S07.php' method='post'><select name='nzv'>";
foreach ($m->sacaNZ() as $nz) { echo "<option value='$nz'>" . $nz . "</option>"; }
echo "</select><input type='submit' value='Buscar Nº Zona' name='nz'><select name='zonav'>";
foreach ($m->sacaZona() as $zona) { echo "<option value='$zona'>" . $zona . "</option>"; }
echo "</select><input type='submit' value='Buscar Zona' name='zona'><select name='aparicionv'>";
foreach ($m->sacaAparicion() as $aparicion) { echo "<option value='$aparicion'>" . $aparicion . "</option>"; }
echo "</select><input type='submit' value='Buscar Aparicion' name='aparicion'><br><br><select name='islav'>";
foreach ($m->sacaIsla() as $isla) { echo "<option value='$isla'>" . $isla . "</option>"; }
echo "</select><input type='submit' value='Buscar Isla' name='isla'></form><br>";
if (isset($_POST["nz"]) || isset($_POST["zona"]) || isset($_POST["aparicion"]) || isset($_POST["isla"])) {
    echo "<table style='text-align: center'><tr><th>Zona</th><th>Aparicion</th><th>Isla</th></tr>";
    foreach ($v as $c) {
        echo "<tr><td id='ng'><div id='cc' class='carousel slide' data-ride='carousel'>" . $c["zona"] .
            "<br><br>Nº Zona: " . $c["nz"] . " (" . $c["act"] . " Acto/s)
            <div id='cc' class='carousel slide' data-ride='carousel'><br><div class='carousel-inner'>
            <div class='carousel-item active'>Act 1<br><br><img src='imgzonas/"
             . $c["zona"] . " Act 1.png' width='475px' height='475px'></div>";
        for ($p = 2; $p < 15; $p++) {
            if ($c["a$p"] != "No") {
                echo "<div class='carousel-item'>Act " . $c["a$p"] . "<br><br><img src='imgzonas/" . $c["zona"] . " Act " .$c["a$p"] .
                    ".png' width='475px' height='475px'></div>";
            }
        }
        echo "</div><a class='carousel-control-prev' href='#cc' data-slide='prev'></a>
            <a class='carousel-control-next' href='#cc' data-slide='next'></a></div></td><td bgcolor='lightgreen'>" . $c["aparicion1"] .
            "<br><br><img src='imgseriepelilogo/" . $c["aparicion1"] . ".png' width='475px' height='475px'>";
        if ($c["isla"] != "Desconocida"){
            echo "</td><td bgcolor='orange'>" . $c["isla"]. "<br><br><img src='imgzonas/" . $c["isla"] .
                ".png' width='475px' height='475px'>";
        } else {
            echo "</td><td bgcolor='orange'>" . $c["isla"]. "<br><br><img src='imgseriepelilogo/" . $c["aparicion1"] .
                ".png' width='475px' height='475px'>";
        } echo "</td></tr>";
    } echo "</table>";
} ?> </body>

</html>
