<!doctype html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <title>Buscar Jefes Sonic</title>
    <link rel='stylesheet' href='https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css'>
    <link rel="stylesheet" href="../ModelosEstilos/CSS2.css">
    <script src='https://code.jquery.com/jquery-3.2.1.slim.min.js'></script>
    <script src='https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js'></script>
</head>

<body>
    <form action='S11.php' method='post' style="margin-top: 10px; text-align: center;">
        <input type="text" name="nz" placeholder="Nº Zona"> <input type="text" name="zona" placeholder="Zona">
        <input type="text" name="aparicion" placeholder="Juego"> <input type="text" name="jefe" placeholder="Jefe">
        <br><br><input type="submit" name="buscarjefe" value="Buscar Jefe">
    </form> <?php try { if (isset($_POST["buscarjefe"])) { $con = new PDO("mysql:host=localhost; dbname=sonicdb", "root", "");
        $con->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION); $con->exec("set character set utf8");
        $res = $con->prepare("SELECT * FROM jefes WHERE nz=? OR zona=? OR aparicion1=? OR jefe1=? OR jefe2=? OR jefe3=?
            OR jefe4=? OR jefe5=? OR jefe6=? OR jefe7=? OR jefe8=?"); $jefe = $_POST["jefe"]; $res->bindParam(1, $_POST["nz"]);
        $res->bindParam(2, $_POST["zona"]);$res->bindParam(3, $_POST["aparicion"]); $res->bindParam(4, $jefe); $res->bindParam(5, $jefe);
        $res->bindParam(6, $jefe); $res->bindParam(7, $jefe); $res->bindParam(8, $jefe); $res->bindParam(9, $jefe);
        $res->bindParam(10, $jefe); $res->bindParam(11, $jefe); $res->execute();
        echo "<table style='text-align: center'><tr><th>Zona</th><th>Aparicion</th><th>Jefe/s</th></tr>";
        while ($c = $res->fetch(PDO::FETCH_ASSOC)) {
            echo "<tr><td id='ng'>" . $c["zona"] . "<br><br>Nº Zona: " . $c["nz"] .
                "<br><br><img src='imgzonas/" . $c["zona"] . " Act 1.png' width='475px' height='475px'>
                </td><td>" . $c["aparicion1"]. "<br><br><img src='imgseriepelilogo/" . $c["aparicion1"] .
                ".png' width='475px' height='475px'></td><td id='ng'><div id='cc' class='carousel slide' data-ride='carousel'>
                <div id='cc' class='carousel slide' data-ride='carousel'><br><div class='carousel-inner'>
                <div class='carousel-item active'>";
            if ($c["jefe1"] != "No"){
                echo $c["jefe1"] ."<br><br><img src='imgrobotsyjefes/".$c["jefe1"].".png' width='475px' height='475px'></div>";
            } else{
                echo "<img src='imgseriepelilogo/" . $c["aparicion1"] . ".png' width='475px' height='475px'>";
            } for ($p = 2; $p < 9; $p++) {
                if ($c["jefe$p"] != "No") {
                    echo "<div class='carousel-item'>" . $c["jefe$p"] . "<br><br><img src='imgrobotsyjefes/"
                        . $c["jefe$p"] . ".png' width='475px' height='475px'></div>";
                } else{ echo ""; }
            }
            echo "</div><a class='carousel-control-prev' href='#cc' data-slide='prev'></a>
                <a class='carousel-control-next' href='#cc' data-slide='next'></a></div></td></tr>";
        } echo "</table>"; $res->closeCursor();
    }
} catch (Exception $e) { echo "¡Error! " . $e->getMessage(); } finally { $con = null; } ?> </body>

</html>
