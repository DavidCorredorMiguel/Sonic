<!doctype html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <title>Zonas De Sonic</title>
    <link rel='stylesheet' href='https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css'>
    <link rel="stylesheet" href="../ModelosEstilos/CSS2.css">
    <script src='https://code.jquery.com/jquery-3.2.1.slim.min.js'></script>
    <script src='https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js'></script>
</head>

<body> <?php $con = new mysqli("localhost", "root", "", "sonicdb"); if (!($res = $con->stmt_init())) { die(mysqli_connect_error());}
if (!isset($_GET["pag"])) { $pag = 1; } else { $pag = $_GET["pag"]; } $resultadopag = 50;
$res->prepare("select count(*) as 'total' from zonas"); $res->execute(); $res->bind_result($total);
$fila = $res->fetch(); $numpag = ceil($total / $resultadopag); $pagactual = ($pag - 1) * $resultadopag;
$res->prepare("select * from zonas LIMIT " . $pagactual . ", " . $resultadopag); $res->execute();
$res->bind_result($idz, $nz, $zona, $aparicion1, $isla, $act, $a2, $a3, $a4, $a5, $a6, $a7, $a8, $a9, $a10, $a11, $a12, $a13, $a14);
echo "<table style='text-align: center'><tr><th>Zona</th><th>Aparicion</th><th>Isla</th></tr>";
while ($res->fetch()) {
    echo "<tr><td id='ng'><div id='cc' class='carousel slide' data-ride='carousel'>" . $zona . "<br><br>Nº Zona: " . $nz . " (" . $act .
        " Acto/s)<div id='cc' class='carousel slide' data-ride='carousel'><br><div class='carousel-inner'>
        <div class='carousel-item active'>Act 1<br><br><img src='imgzonas/" . $zona . " Act 1.png' width='475px' height='475px'></div>";
    if ($a2 != "No") {
        echo "<div class='carousel-item'>Act 2<br><br><img src='imgzonas/" . $zona . " Act 2.png' width='475px' height='475px'></div>";
    }
    if ($a3 != "No") {
        echo "<div class='carousel-item'>Act 3<br><br><img src='imgzonas/" . $zona . " Act 3.png' width='475px' height='475px'></div>";
    }
    if ($a4 != "No") {
        echo "<div class='carousel-item'>Act 4<br><br><img src='imgzonas/" . $zona . " Act 4.png' width='475px' height='475px'></div>";
    }
    if ($a5 != "No") {
        echo "<div class='carousel-item'>Act 5<br><br><img src='imgzonas/" . $zona . " Act 5.png' width='475px' height='475px'></div>";
    }
    if ($a6 != "No") {
        echo "<div class='carousel-item'>Act 6<br><br><img src='imgzonas/" . $zona . " Act 6.png' width='475px' height='475px'></div>";
    }
    if ($a7 != "No") {
        echo "<div class='carousel-item'>Act 7<br><br><img src='imgzonas/" . $zona . " Act 7.png' width='475px' height='475px'></div>";
    }
    if ($a8 != "No") {
        echo "<div class='carousel-item'>Act 8<br><br><img src='imgzonas/" . $zona . " Act 8.png' width='475px' height='475px'></div>";
    }
    if ($a9 != "No") {
        echo "<div class='carousel-item'>Act 9<br><br><img src='imgzonas/" . $zona . " Act 9.png' width='475px' height='475px'></div>";
    }
    if ($a10 != "No") {
        echo "<div class='carousel-item'>Act 10<br><br><img src='imgzonas/" . $zona . " Act 10.png' width='475px' height='475px'></div>";
    }
    if ($a11 != "No") {
        echo "<div class='carousel-item'>Act 11<br><br><img src='imgzonas/" . $zona . " Act 11.png' width='475px' height='475px'></div>";
    }
    if ($a12 != "No") {
        echo "<div class='carousel-item'>Act 12<br><br><img src='imgzonas/" . $zona . " Act 12.png' width='475px' height='475px'></div>";
    }
    if ($a13 != "No") {
        echo "<div class='carousel-item'>Act 13<br><br><img src='imgzonas/" . $zona . " Act 13.png' width='475px' height='475px'></div>";
    }
    if ($a14 != "No") {
        echo "<div class='carousel-item'>Act 14<br><br><img src='imgzonas/" . $zona . " Act 14.png' width='475px' height='475px'></div>";
    }
    echo "</div><a class='carousel-control-prev' href='#cc' data-slide='prev'></a>
        <a class='carousel-control-next' href='#cc' data-slide='next'></a></div></td><td bgcolor='lightgreen'>" . $aparicion1 .
        "<br><br><img src='imgseriepelilogo/" . $aparicion1 . ".png' width='475px' height='475px'>";
    if ($isla != "Desconocida"){
        echo "</td><td bgcolor='orange'>" . $isla. "<br><br><img src='imgzonas/" . $isla . ".png' width='475px' height='475px'>";
    } else {
        echo "</td><td bgcolor='orange'>" .$isla."<br><br><img src='imgseriepelilogo/".$aparicion1.".png' width='475px' height='475px'>";
    } echo "</td></tr>";
} echo "</table><br><br><div id='pag' style='text-align: center'>";
if ($pag != 1) { echo " <a href='S09.php?pag=" . ($pag - 1) . "'><</a> <a href='S09.php?pag=1'>1</a> "; }
for ($i = $pag - 1; $i < $pag + 2; $i++) { if ($i > 1 && $i <= $numpag) { echo " <a href='S09.php?pag=" . $i . "'>$i</a> "; } }
if ($pag != $numpag) { echo " ... <a href='S09.php?pag=$numpag'>$numpag</a> <a href='S09.php?pag=" . ($pag + 1) . "'>></a>"; }
echo "<br><br></div>"; $res->close(); ?> </body>

</html>