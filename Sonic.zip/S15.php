<!doctype html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <title>Musica De Sonic</title>
    <link rel="stylesheet" href="../ModelosEstilos/CSS2.css">
</head>

<body> <?php $con = new mysqli("localhost", "root", "", "sonicdb"); if (!($res = $con->stmt_init())) { die(mysqli_connect_error());}
if (!isset($_GET["pag"])) { $pag = 1; } else { $pag = $_GET["pag"]; } $resultadopag = 50;
$res->prepare("select count(*) as 'total' from musica"); $res->execute(); $res->bind_result($total);
$fila = $res->fetch(); $numpag = ceil($total / $resultadopag); $pagactual = ($pag - 1) * $resultadopag;
$res->prepare("select * from musica LIMIT " . $pagactual . ", " . $resultadopag); $res->execute();
$res->bind_result($idm, $nz, $zonacancion, $cancionjuego, $temap, $artistatp, $temafinal, $artistatf);
echo "<table style='text-align: center'><tr><th>Zona</th><th>Juego</th><th>Tema Principal</th><th>Tema Final</th></tr>";
while ($res->fetch()) {
    echo "<tr><td id='ng'>" . $zonacancion . "<br><br>Nº Zona: " . $nz .
        "<br><br><img src='imgzonas/" . $zonacancion . " Act 1.png' width='350px' height='350px'></td><td>" . $cancionjuego .
        "<br><br><img src='imgseriepelilogo/" . $cancionjuego . ".png' width='350px' height='350px'></td><td>";
    if ($temap != "No") {
        echo $temap . "<br><br>" . $artistatp . "<br><br><audio src='musica/" . $temap .
            ".oga' style='width: 250px;' controls=''></audio></div>";
    } else { echo "<img src='imgseriepelilogo/" . $cancionjuego . ".png' width='350px' height='350px'>"; }
    echo "</td><td>";
    if ($temafinal != "No") {
        echo $temafinal . "<br><br>" . $artistatf . "<br><br><audio src='musica/" . $temafinal .
            ".oga' style='width: 250px;' controls=''></audio></div>";
    } else { echo "<img src='imgseriepelilogo/" . $cancionjuego . ".png' width='350px' height='350px'>"; } echo "</td></tr>";
} echo "</table><br><br><div id='pag' style='text-align: center'>";
if ($pag != 1) { echo " <a href='S15.php?pag=" . ($pag - 1) . "'><</a> <a href='S15.php?pag=1'>1</a> "; }
for ($i = $pag - 1; $i < $pag + 2; $i++) { if ($i > 1 && $i <= $numpag) { echo " <a href='S15.php?pag=" . $i . "'>$i</a> "; } }
if ($pag != $numpag) { echo " ... <a href='S15.php?pag=$numpag'>$numpag</a> <a href='S15.php?pag=" . ($pag + 1) . "'>></a>"; }
echo "<br><br></div>"; $res->close(); ?> </body>

</html>