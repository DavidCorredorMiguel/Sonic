<!doctype html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <title>Musica Zonas De Sonic</title>
    <link rel='stylesheet' href='https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css'>
    <link rel="stylesheet" href="../ModelosEstilos/CSS2.css">
    <script src='https://code.jquery.com/jquery-3.2.1.slim.min.js'></script>
    <script src='https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js'></script>
</head>

<body> <?php require_once "../ModelosEstilos/SonicM07.php"; $m = new SonicM07(); $v = array();
if (isset($_POST["nz"])) { $v = $m->getNZ(); } if (isset($_POST["zona"])) { $v = $m->getZonaCancion(); }
if (isset($_POST["juego"])) { $v = $m->getCancionJuego(); } if (isset($_POST["jefe"])) { $v = $m->getJefe(); }
if (isset($_POST["cjefe"])) { $v = $m->getCJefe(); } if(isset($_POST["artista"])) { $v = $m->getArtista(); }
echo "<br><form action='S19.php' method='post'><select name='nzv'>";
foreach ($m->sacaNZ() as $nz) { echo "<option value='$nz'>" . $nz . "</option>"; }
echo "</select><input type='submit' value='Buscar Nº Zona' name='nz'><select name='zcv'>";
foreach ($m->sacaZonaCancion() as $zona) { echo "<option value='$zona'>" . $zona . "</option>"; }
echo "</select><input type='submit' value='Buscar Zona' name='zona'><select name='cjv'>";
foreach ($m->sacaCancionJuego() as $juego) { echo "<option value='$juego'>" . $juego . "</option>"; }
echo "</select><input type='submit' value='Buscar juego' name='juego'><br><br><select name='jefev'>";
foreach ($m->sacaJefe() as $jefe) { echo "<option value='$jefe'>" . $jefe . "</option>"; }
echo "</select><input type='submit' value='Buscar Jefe' name='jefe'><select name='cjefev'>";
foreach ($m->sacaCJefe() as $cjefe) { echo "<option value='$cjefe'>" . $cjefe . "</option>"; }
echo "</select><input type='submit' value='Buscar Musica Jefe' name='cjefe'><br><br><select name='artistav'>";
foreach ($m->sacaArtista() as $artista) { echo "<option value='$artista'>" . $artista . "</option>"; }
echo "</select><input type='submit' value='Buscar Artista Zona' name='artista'></form><br>";
if (isset($_POST["nz"]) || isset($_POST["zona"]) || isset($_POST["juego"]) || isset($_POST["jefe"]) || isset($_POST["cjefe"])
    || isset($_POST["artista"])) {
    echo "<table style='text-align: center'><tr><th>Zona</th><th>Juego</th><th>Musica y Artista/s</th></tr>";
    foreach ($v as $c) {
        echo "<tr><td bgcolor='black' style='color: white'>" . $c["zonacancion"] . "<br><br>Nº Zona: " . $c["nz"] .
            "<img src='imgzonas/" . $c["zonacancion"] . " Act 1.png' width='350px' height='350px'></td><td>" .
            $c["cancionjuego"] . "<br><br><img src='imgseriepelilogo/" . $c["cancionjuego"] .
            ".png' width='300px' height='300px'></td><td bgcolor='black' style='color: white'>
            <div id='cc' class='carousel slide' data-ride='carousel'>
            <div class='carousel-inner'><div class='carousel-item active'>";
        if ($c["cjefe1"] != "No") {
            echo "Artista/s: " . $c["artistaj1"] . "<br>Jefe: " . $c["jefe1"] . "<br>Cancion: " . $c["cjefe1"] .
                "<br><audio src='musica/Jefe " . $c["cjefe1"] . ".oga' style='width: 250px;' controls=''></audio>
                <br><img src='imgrobotsyjefes/" . $c["jefe1"] . ".png' width='300px' height='300px'>";
        } else { echo "<img src='imgseriepelilogo/".$c["cancionjuego"].".png' width='300px' height='300px'>"; } echo "</div>";
        for ($p = 2; $p <= 8; $p++) { echo "<div class='carousel-item'>";
            if ($c["cjefe$p"] != "No") {
                echo "Artista/s: " . $c["artistaj$p"] . "<br>Jefe: " . $c["jefe$p"] . "<br>Cancion: " .
                    $c["cjefe$p"] . "<br><audio src='musica/Jefe " . $c["cjefe$p"] .
                    ".oga' style='width: 250px;' controls=''></audio><br><img src='imgrobotsyjefes/" .
                    $c["jefe$p"] . ".png' width='300px' height='300px'></div>";
            } else {echo "<img src='imgseriepelilogo/" . $c["cancionjuego"].".png' width='300px' height='300px'>";} echo "</div>";
        }
        echo "<a class='carousel-control-prev' href='#cc' data-slide='prev'></a>
            <a class='carousel-control-next' href='#cc' data-slide='next'></a></div></td></tr>";
    } echo "</table>";
} ?> </body>

</html>
