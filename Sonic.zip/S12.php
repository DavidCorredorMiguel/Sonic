<!doctype html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <title>Jefes De Sonic</title>
    <link rel='stylesheet' href='https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css'>
    <link rel="stylesheet" href="../ModelosEstilos/CSS2.css">
    <script src='https://code.jquery.com/jquery-3.2.1.slim.min.js'></script>
    <script src='https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js'></script>
</head>

<body> <?php $con = new mysqli("localhost", "root", "", "sonicdb"); if (!($res = $con->stmt_init())) { die(mysqli_connect_error());}
if (!isset($_GET["pag"])) { $pag = 1; } else { $pag = $_GET["pag"]; } $resultadopag = 50;
$res->prepare("select count(*) as 'total' from jefes"); $res->execute(); $res->bind_result($total);
$fila = $res->fetch(); $numpag = ceil($total / $resultadopag); $pagactual = ($pag - 1) * $resultadopag;
$res->prepare("select * from jefes LIMIT " . $pagactual . ", " . $resultadopag); $res->execute();
$res->bind_result($idj, $nz, $zona, $aparicion1, $jefe1, $jefe2, $jefe3, $jefe4, $jefe5, $jefe6, $jefe7, $jefe8);
echo "<table style='text-align: center'><tr><th>Zona</th><th>Aparicion</th><th>Jefe/s</th></tr>";
while ($res->fetch()) {
    echo "<tr><td id='ng'>" . $zona . "<br><br>Nº Zona: " . $nz .
        "<br><br><img src='imgzonas/" . $zona . " Act 1.png' width='475px' height='475px'></td><td>" . $aparicion1.
        "<br><br><img src='imgseriepelilogo/" . $aparicion1 . ".png' width='475px' height='475px'></td><td id='ng'>
         <div id='cc' class='carousel slide' data-ride='carousel'>
        <div id='cc' class='carousel slide' data-ride='carousel'><br><div class='carousel-inner'>
        <div class='carousel-item active'>";
    if ($jefe1 != "No"){
        echo $jefe1 . "<br><br><img src='imgrobotsyjefes/" . $jefe1 . ".png' width='475px' height='475px'></div>";
    } else { echo "<img src='imgseriepelilogo/" . $aparicion1 . ".png' width='475px' height='475px'>"; }
    if ($jefe2 != "No") {
        echo"<div class='carousel-item'>".$jefe2."<br><br><img src='imgrobotsyjefes/".$jefe2.".png' width='475px' height='475px'></div>";
    } else{ echo ""; }
    if ($jefe3 != "No") {
        echo"<div class='carousel-item'>".$jefe3."<br><br><img src='imgrobotsyjefes/".$jefe3.".png' width='475px' height='475px'></div>";
    } else{ echo ""; }
    if ($jefe4 != "No") {
        echo"<div class='carousel-item'>".$jefe4."<br><br><img src='imgrobotsyjefes/".$jefe4.".png' width='475px' height='475px'></div>";
    } else{ echo ""; }
    if ($jefe5 != "No") {
        echo"<div class='carousel-item'>".$jefe5."<br><br><img src='imgrobotsyjefes/".$jefe5.".png' width='475px' height='475px'></div>";
    } else{ echo ""; }
    if ($jefe6 != "No") {
        echo"<div class='carousel-item'>".$jefe6."<br><br><img src='imgrobotsyjefes/".$jefe6.".png' width='475px' height='475px'></div>";
    } else{ echo ""; }
    if ($jefe7 != "No") {
        echo"<div class='carousel-item'>".$jefe7."<br><br><img src='imgrobotsyjefes/".$jefe7.".png' width='475px' height='475px'></div>";
    } else{ echo ""; }
    if ($jefe8 != "No") {
        echo"<div class='carousel-item'>".$jefe8."<br><br><img src='imgrobotsyjefes/".$jefe8.".png' width='475px' height='475px'></div>";
    } else{ echo ""; }
    echo "</div><a class='carousel-control-prev' href='#cc' data-slide='prev'></a>
        <a class='carousel-control-next' href='#cc' data-slide='next'></a></div></td></tr>";
} echo "</table><br><br><div id='pag' style='text-align: center'>";
if ($pag != 1) { echo " <a href='S12.php?pag=" . ($pag - 1) . "'><</a> <a href='S12.php?pag=1'>1</a> "; }
for ($i = $pag - 1; $i < $pag + 2; $i++) { if ($i > 1 && $i <= $numpag) { echo " <a href='S12.php?pag=" . $i . "'>$i</a> "; } }
if ($pag != $numpag) { echo " ... <a href='S12.php?pag=$numpag'>$numpag</a> <a href='S12.php?pag=" . ($pag + 1) . "'>></a>"; }
echo "<br><br></div>"; $res->close(); ?> </body>

</html>
